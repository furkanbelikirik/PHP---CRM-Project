# PHP-CRMProje
İnternet Tabanlı Programlama (BTO3041) dersi için Furkan Belikırık ile ortak geliştirilen proje

Database klasörü içerisindeki .sql dosyasını oluşturduğunuz veritabanına import ediniz.
Daha sonra veri klasörü içerisindeki ayar.php dosyasından veritabanı bağlantı bilgilerini güncelleyiniz.
