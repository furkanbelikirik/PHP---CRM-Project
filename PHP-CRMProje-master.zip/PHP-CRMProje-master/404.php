<?php require_once('header.php'); ?>


<ol class="breadcrumb bc-3"> <li> <a href="index.php"><i class="fa-home"></i>Neon CRM </a> </li> <li> <a href="#">Kullanıcı</a> </li> <li class="active"> <strong>Giriş Sayfası</strong> </li> </ol>


<div class="jumbotron"> <h1>Yapımda</h1>
<p>Merhaba! Bu sayfayı görüyorsanız ya bir şeyler yanlış gitti, ya da sayfa henüz yapım aşamasında, lütfen kısa bir süre sonra sayfayı tekrar ziyaret etmeyi dene..</p>
</p> <p> <br> </p><div class="btn btn-primary btn-lg">Güncel Versiyon: <strong>v2.0</strong></div> <p></p> </div>
		<div class="row">
			
			<div class="col-md-12">
			


			</div>


			</div>







<?php include("footer.php"); ?>