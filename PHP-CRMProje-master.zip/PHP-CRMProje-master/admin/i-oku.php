<?php require_once('header.php'); 
error_reporting(0);
?>